RENZ Bot v63 Android App Source

Purpose:
- Real Android app source for Android Studio.
- Loads the simplified RENZ Bot mobile dashboard inside an Android WebView.
- Uses the Android native bridge to call your Apps Script Web App URL, so the app does not need XAMPP/PHP for Apps Script calls.
- Still paper trading only. No real exchange orders.

Included:
- app/src/main/assets/index.html
- Java WebView app
- Native bridge for Apps Script actions: status, collect, learn, predict, performance, save_trade, etc.
- Preset Apps Script URL already inside the dashboard.

Requirements:
- Android Studio installed on PC/laptop.
- Internet connection.
- Your Apps Script deployment must remain active and accessible to Anyone.

How to build APK:
1. Extract this ZIP.
2. Open Android Studio.
3. File > Open.
4. Select the folder: renz_bot_v63_android_app_source
5. Wait for Gradle Sync to finish.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. When build finishes, click Locate.
8. Transfer the APK to your Android phone.
9. On phone, allow Install unknown apps if Android asks.
10. Install and open RENZ Bot v63.

First run:
1. Click Test.
2. Click Sync Online Performance.
3. Click Predict.
4. Use Paper Learning mode for testing.

Notes:
- This app does not execute real trades.
- If you close the phone app, the dashboard-side auto paper trade monitoring stops.
- Apps Script can still continue online candle collection/learning if triggers are installed.
- For fully autonomous paper trading while app is closed, the trade engine must be moved to Apps Script in a future version.

Apps Script URL currently preset:
https://script.google.com/macros/s/AKfycbxOWuOUwWzmQv5MSuWdFyHM1ffX9D3EjXg15kJ8Y-EwMqtT52-6sa7ThgUFL7WnnDE5/exec
