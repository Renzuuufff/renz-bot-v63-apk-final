package com.renzbot.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new RenzNativeBridge(), "RenzNative");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    public class RenzNativeBridge {
        @JavascriptInterface
        public void request(String webappUrl, String action, String paramsJson, String callbackId) {
            new Thread(() -> {
                String response;
                try {
                    response = callAppsScript(webappUrl, action, paramsJson);
                    final String js = "window.__renzNativeResolve(" + quote(callbackId) + "," + response + ");";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                } catch (Exception e) {
                    String errorJson = "{\"__error\":" + quote(e.getMessage()) + "}";
                    final String js = "window.__renzNativeResolve(" + quote(callbackId) + "," + errorJson + ");";
                    runOnUiThread(() -> webView.evaluateJavascript(js, null));
                }
            }).start();
        }

        private String callAppsScript(String webappUrl, String action, String paramsJson) throws Exception {
            if (webappUrl == null || !webappUrl.startsWith("https://script.google.com/macros/s/")) {
                throw new Exception("Invalid Apps Script Web App URL. Use the /exec URL.");
            }

            StringBuilder urlBuilder = new StringBuilder(webappUrl);
            urlBuilder.append(webappUrl.contains("?") ? "&" : "?");
            urlBuilder.append("action=").append(enc(action));

            if (paramsJson != null && !paramsJson.trim().isEmpty()) {
                JSONObject obj = new JSONObject(paramsJson);
                Iterator<String> keys = obj.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    Object value = obj.opt(key);
                    if (value != null && !JSONObject.NULL.equals(value)) {
                        urlBuilder.append("&").append(enc(key)).append("=").append(enc(String.valueOf(value)));
                    }
                }
            }

            URL url = new URL(urlBuilder.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("Accept", "application/json,text/plain,*/*");
            conn.setRequestProperty("User-Agent", "RENZBotAndroidWebView/63");
            conn.setInstanceFollowRedirects(true);

            int code = conn.getResponseCode();
            InputStream stream = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
            String body = readAll(stream);
            conn.disconnect();

            if (code < 200 || code >= 400) {
                throw new Exception("Apps Script HTTP " + code + ": " + preview(body));
            }
            String trimmed = body.trim();
            if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
                throw new Exception("Apps Script returned non-JSON: " + preview(body));
            }
            return trimmed;
        }

        private String enc(String s) throws Exception {
            return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8.name());
        }

        private String readAll(InputStream stream) throws Exception {
            if (stream == null) return "";
            BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        }

        private String preview(String s) {
            if (s == null) return "";
            return s.length() > 220 ? s.substring(0, 220) : s;
        }
    }

    private static String quote(String s) {
        if (s == null) s = "";
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 32) out.append(String.format("\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        out.append("\"");
        return out.toString();
    }
}
